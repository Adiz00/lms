import { createContext, useState } from "react";

export const IsLoginContext = createContext(null);

export const IsLoginProvider = (props) => {
  const [isLogin, setIsLogin] = useState(false);
  const [coursesArr, setCoursesArr] = useState([
    {
      id: "1",
      assistantTrainers: ["mohsin", "shunaid"],
      courseDuration: "2",
      courseFee: "2499",
      courseName: "ss2",
      isFormOpen: true,
      leadTrainerId: "23",
      noOfQuiz: "5",
    },
    {
      id: "2",
      assistantTrainers: ["mohsin", "shunaid"],
      courseDuration: "4",
      courseFee: "2000",
      courseName: "ss3",
      isFormOpen: false,
      leadTrainerId: "22",
      noOfQuiz: "2",
    },
  ]);
  const [quizArr, setQuizArr] = useState([
    {
      id: "1",
      questions: [
        {
            queId:1,
          que: "www stands for",
          options: ["", "", "", ""],
          correctAns: "world wide web",
        },
        {
            queId:2,
          que: "www stands for",
          options: ["", "", "", ""],
          correctAns: "world wide web",
        },
        {
            queId:3,
          que: "www stands for",
          options: ["", "", "", ""],
          correctAns: "world wide web",
        },
      ],
      quizNo: "1",
      courseName: "web",
      noOfQuestion: "12",
      isQuizOpen: false,
      totalMarks: "50",
      QuizDuration: "20",
      evaluationDate: "5-12-22",
    },
    {
      id: "2",
      questions: [
        {
            queId:1,
          que: "www stands for",
          options: ["", "", "", ""],
          correctAns: "world wide web",
        },
        {
            queId:2,
          que: "www stands for",
          options: ["", "", "", ""],
          correctAns: "world wide web",
        },
        {
            queId:3,
          que: "www stands for",
          options: ["", "", "", ""],
          correctAns: "world wide web",
        },
      ],
      quizNo: "2",
      courseName: "app",
      noOfQuestion: "12",
      isQuizOpen: false,
      totalMarks: "50",
      QuizDuration: "20",
      evaluationDate: "5-12-22",
    },
  ]);
  const[regArr,setRegArr]=useState([{
    id:1,
    firstName:"John",
    lastName:"Pat",
    course:"web",
    sec:"A",
    cnic:"11221233434",
    fatherName:"Pat",
    fatherCnic:"22337378383",
    fatherContact:"0990089765",
    emergencyContact:"0990089765",
    dob:"12,2,2000"
  },
  {
    id:2,
    firstName:"John",
    lastName:"son",
    course:"web",
    sec:"A",
    cnic:"11221233434",
    fatherName:"Pat",
    fatherCnic:"22337378383",
    fatherContact:"0990089765",
    emergencyContact:"0990089765",
    dob:"12,2,2000"
  }]);
  return (
    <IsLoginContext.Provider
      value={{
        isLogin,
        setIsLogin,
        coursesArr,
        setCoursesArr,
        quizArr,
        setQuizArr,
        regArr,
        setRegArr
      }}
    >
      {props.children}
    </IsLoginContext.Provider>
  );
};
