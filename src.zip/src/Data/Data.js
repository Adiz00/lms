export let coursesArr=[{
    id:"1",
    assistantTrainers: ['mohsin', 'shunaid', 'bacha', ],
    courseDuration: "2",
    courseFee: "2499",
    courseName: "ss2",
    isFormOpen: true,
    leadTrainerId: "23",
    noOfQuiz: "5"},
    {
        id:"2",
        assistantTrainers: ['mohsin', 'shunaid', 'bacha', ],
        courseDuration: "4",
        courseFee: "2000",
        courseName: "ss3",
        isFormOpen: false,
        leadTrainerId: "22",
        noOfQuiz: "2"},  
    ];