import React, { useContext, useState } from "react";
import SideBar from "../components/SideBar";
import Grid from "@mui/material/Grid";
import { Box, Chip, FormControlLabel, Switch } from "@mui/material";
import Container from "@mui/material/Container";
import InputFieldMui from "../components/InputFieldMui";
import BtnMui from "../components/BtnMui";
import { useNavigate } from "react-router";
import { coursesArr } from "../Data/Data";
import { IsLoginContext } from "../context/UserContext";
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import {getDatabase,push,ref, set} from "firebase/database"
import {app,auth} from "../firebase"

const database=getDatabase(app);

const AddRegistration = () => {
  // getting courses Arr from context  
  const regArrContext = useContext(IsLoginContext);

  // courses obj
const [regObj, setRegObj] = useState({
  id:"",
  isActive:false,
  isApproved:false,
});

console.log(regObj);



// inputchangeHandler
const inputChangeHandler = (event) => {
  setRegObj((oldObj) => ({
    ...oldObj,
    [event.target.name]: event.target.value,
  }));
};

// isFormOpen Switch
const [checked, setChecked] = useState(false);

const handleChange = (event) => {
  setChecked(event.target.checked);

  console.log("checked", checked);
  setRegObj((oldObj) => ({
    ...oldObj,
    isActive: checked ? false : true,
  }));
  // console.log(coursesObj.isFormOpen);

  
};

// navigate to admin courses   
const navigate =useNavigate();
const goToAdminCourses =()=>{
  navigate('/adminRegistration');
}

//   Form submil
const addRegistrationFormSubmit =(e)=>{
  e.preventDefault();
  // console.log("submit");
  // setCoursesObj((oldObj)=> ({...oldObj,assistantTrainers:[...assisTrainerArr]}))
  // console.log(coursesObj);

  regObj.category="std";

    const regRefrence=ref(database,"Registration/")
    regObj.id=push(regRefrence).key;
    set(ref(database,`Registration/${regObj.id}`),regObj)
    .then((res)=>{alert("data sent successfully")})
    .catch((err)=>{alert(err.message)})
    
    goToAdminCourses();
  // if(regObj.id =="")
  // {
  //     alert('enter course id')
  // }

  // else{

      
  //     regArrContext.setRegArr(oldArr => [...oldArr,regObj]);
  //    console.log(regArrContext.regArr);
  
  // }
     
  
  
}
  return (
    <div>
      <SideBar />
<form onSubmit={addRegistrationFormSubmit}>
      <Container>
        <Grid
          container
          rowSpacing={3}
          columnSpacing={2}
          sx={{ width: "100%", marginLeft: "0%" }}
        >
          <Grid item xs={12} sm={12} md={12} sx={{ textAlign: "start" }}>
            <h2 style={{ padding: "0px", margin: "0px" }}>Registration Info</h2>
          </Grid>
          <Grid item xs={12} sm={12} md={12} sx={{ textAlign: "start" }}>
            <FormControlLabel
              control={
                <Switch
                  checked={checked}
                  onChange={handleChange}
                  inputProps={{ "aria-label": "controlled" }}
                />
              }
              label="Is Active"
              labelPlacement="start"
              sx={{ padding: "0px", margin: "0px" }}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              label="Std Id"
              variant="filled"
              size="small"
              name="id"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
            
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              label="First Name"
              variant="filled"
              size="small"
              name="firstName"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
            
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              
              label="Last Name"
              variant="filled"
              size="small"
              name="lastName"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              
              label="Course"
              variant="filled"
              size="small"
              name="course"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              
              label="Sec"
              variant="filled"
              size="small"
              name="sec"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              label="Contact"
              variant="filled"
              size="small"
              name="contact"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
          </Grid>
          
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
               label="CNIC"
               variant="filled"
               size="small"
               name="cnic"
               onChange={(e)=>{inputChangeHandler(e);}}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4} >
            <InputFieldMui
              label="Father Name"
              variant="filled"
              size="small"
              name="fatherName"
              onChange={(e)=>{inputChangeHandler(e);}}
           />
          </Grid>
          <Grid item xs={12} sm={6} md={4} >
            <InputFieldMui
              label="Father CNIC"
              variant="filled"
              size="small"
              name="fatherCnic"
              onChange={(e)=>{inputChangeHandler(e);}}
           />
          </Grid>
          <Grid item xs={12} sm={6} md={4} >
            <InputFieldMui
              label="Father Contact"
              variant="filled"
              size="small"
              name="fatherContact"
              onChange={(e)=>{inputChangeHandler(e);}}
           />
          </Grid>
          <Grid item xs={12} sm={6} md={4} >
            <InputFieldMui
              label="Emergency Contact"
              variant="filled"
              size="small"
              name="EmergencyContact"
              onChange={(e)=>{inputChangeHandler(e);}}
           />
          </Grid>
          <Grid item xs={12} sm={6} md={4} >
          <LocalizationProvider dateAdapter={AdapterDayjs} >
      <DatePicker
        name="dob"
        label="DOB"
        // value={dob}
        onChange={(newValue) => {
        //   setDob(newValue);
          setRegObj((oldObj) => ({
            ...oldObj,
            "dob": newValue.$M+"-"+newValue.$D+"-"+newValue.$y,
          }));
        }}
        renderInput={(params) => 
        
        <TextField sx={{width:"100%"}} {...params} />}
       
      />
    </LocalizationProvider>
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={10}
            sx={{ textAlign: "end", display: "inline-block" }}
          >
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={1}
            sx={{ textAlign: "end", display: "inline-block" }}
          >
            <BtnMui variant="outlined" text="cancel" sx={{}} onClick={()=>{navigate("/adminRegistration")}} />
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={1}
            sx={{ textAlign: "end", display: "inline-block" }}
          >
            <BtnMui type="submit" variant="contained" text="submit" sx={{}} />
          </Grid>
        </Grid>
      </Container>
      </form>
    </div>
  )
}

export default AddRegistration