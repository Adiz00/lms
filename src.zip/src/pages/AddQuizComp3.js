import React from 'react'
import BtnMui from '../components/BtnMui'

const AddQuizComp3 = ({addQuizFormSubmit}) => {
  return (
    <div> <BtnMui
    variant="contained"
    onClick={addQuizFormSubmit}
    text="Create Quiz"
  /></div>
  )
}

export default AddQuizComp3