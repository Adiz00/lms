import React, { useContext, useState } from "react";
import SideBar from "../components/SideBar";
import Grid from "@mui/material/Grid";
import { Box, Chip, FormControlLabel, Switch } from "@mui/material";
import Container from "@mui/material/Container";
import InputFieldMui from "../components/InputFieldMui";
import BtnMui from "../components/BtnMui";
import { useNavigate } from "react-router";
import { coursesArr } from "../Data/Data";
import { IsLoginContext } from "../context/UserContext";


const AddQuizCopm1 = ({quizesObj,setQuizesObj}) => {

   
    
  
    // courses obj
 
  
  
  
  
  // const [assisTrainer, setAssisTrainer] = useState("");
  // const setArrOffAssTran = () => {
  //   setAssisTrainerArr((oldArr) => [...oldArr, assisTrainer]);
    // console.log(assisTrainerArr);
  
    
  // };
  
  // inputchangeHandler
  const inputChangeHandler = (event) => {
    setQuizesObj((oldObj) => ({
      ...oldObj,
      [event.target.name]: event.target.value,
    }));
  };
  
  // isFormOpen Switch
  const [checked, setChecked] = useState(false);
  
  const handleChange = (event) => {
    setChecked(event.target.checked);
  
    console.log("checked", checked);
    setQuizesObj((oldObj) => ({
      ...oldObj,
      isQuizOpen: checked ? false : true,
    }));
    // console.log(coursesObj.isFormOpen);
  
    
  };
  
  // navigate to admin courses   
  const navigate =useNavigate();
  const goToAdminQuiz =()=>{
    navigate('/adminQuiz');
  }
  
  //   Form submil
  const addQuizFormSubmit =(e)=>{
    e.preventDefault();
    // console.log("submit");
    // setQuizesObj((oldObj)=> ({...oldObj,assistantTrainers:[...assisTrainerArr]}))
    // console.log(coursesObj);
  
    // if(coursesObj.id =="")
    // {
    //     alert('enter course id')
    // }
  
    // else{
  
        
    //     coursesArrContext.setCoursesArr(oldArr => [...oldArr,coursesObj]);
    //     // console.log(coursesArrContext.coursesArr);
        goToAdminQuiz();
    
    // }
       
    
    
  }
  return (
    <div>
     

      <Container>
        <Grid
          container
          rowSpacing={3}
          columnSpacing={2}
          sx={{ width: "100%", marginLeft: "0%" }}
        >
          <Grid item xs={12} sm={12} md={12} sx={{ textAlign: "start" }}>
            <h2 style={{ padding: "0px", margin: "0px" }}>Quiz Info</h2>
          </Grid>
          <Grid item xs={12} sm={12} md={12} sx={{ textAlign: "start" }}>
            <FormControlLabel
              control={
                <Switch
                  checked={checked}
                  onChange={handleChange}
                  inputProps={{ "aria-label": "controlled" }}
                />
              }
              label="Is Quiz Open"
              labelPlacement="start"
              sx={{ padding: "0px", margin: "0px" }}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              label="Quiz Id"
              variant="filled"
              size="small"
              name="id"
              type="number"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
            
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              label="Quiz No"
              variant="filled"
              size="small"
              name="quizNo"
              type="number"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
            
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              
              label="Course Name"
              variant="filled"
              size="small"
              name="courseName"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
          </Grid>
          {/* <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              type="number"
              label="No Of Question"
              variant="filled"
              size="small"
              name="noOfQuestion"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
          </Grid> */}
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              type="number"
              label="Total Marks"
              variant="filled"
              size="small"
              name="totalMarks"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              label="Quiz Duration (min)"
              variant="filled"
              size="small"
              name="quizDuration"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              label="Evaluation Date"
              variant="filled"
              size="small"
              name="evaluationDate"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
          </Grid>
         
         {/* buttons */}
          <Grid
            item
            xs={12}
            sm={12}
            md={10}
            sx={{ textAlign: "start", display: "inline-block" }}
          >
            {/* {assisTrainerArr.map((x, i) => {
              return (
                <Chip
                  sx={{ marginRight: "10px", padding: "5px" }}
                  key={i}
                  label={x}
                  variant="outlined"
                  color="success"
                />
              );
            })} */}
          </Grid>
          {/* <Grid
            item
            xs={12}
            sm={12}
            md={1}
            sx={{ textAlign: "end", display: "inline-block" }}
          >
            <BtnMui variant="outlined" text="cancel" sx={{}} onClick={()=>{navigate("/")}} />
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={1}
            sx={{ textAlign: "end", display: "inline-block" }}
          >
            <BtnMui type="submit" variant="contained" text="submit" sx={{}} />
          </Grid> */}
        </Grid>

       
      </Container>
      
    </div>
 );
};
export default AddQuizCopm1