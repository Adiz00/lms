import React from 'react'
import StdSideBar from "../components/StdSideBar"


const StdCourses = () => {
  return (
    <div><StdSideBar />StdCourses</div>
  )
}

export default StdCourses