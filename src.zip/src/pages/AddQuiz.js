import React, { useContext, useState } from "react";
import SideBar from "../components/SideBar";
import Grid from "@mui/material/Grid";
import { Box, Chip, FormControlLabel, Switch } from "@mui/material";
import Container from "@mui/material/Container";

// import Box from '@mui/material/Box';
import { useTheme } from '@mui/material/styles';
import MobileStepper from '@mui/material/MobileStepper';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import KeyboardArrowLeft from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRight from '@mui/icons-material/KeyboardArrowRight';
import AddQuizCopm1 from "./AddQuizCopm1";
import AddQuizComp2 from "./AddQuizComp2";
import AddQuizComp3 from "./AddQuizComp3";
import { IsLoginContext } from "../context/UserContext";
import { Navigate, useNavigate } from "react-router";
import {getDatabase,push,ref, set} from "firebase/database"
import {app,auth} from "../firebase"

const database=getDatabase(app);

const AddQuiz = () => {

  // /////////////////////////// Quiz obj ////////////////////////////////

  const [quizesObj, setQuizesObj] = useState({
    id:"",
    isQuizOpen:false,
    question:[],
    
    
  });
console.log('quizesobj',quizesObj);
  // getting courses Arr from context  
  const quizArrContext = useContext(IsLoginContext);

// submitting form  

 const navigate=useNavigate();

  const addQuizFormSubmit=()=>{
    // console.log('addQuizFormSubmit')
    quizArrContext.setQuizArr((oldArr)=>[...oldArr,quizesObj])

    const regRefrence=ref(database,"Quizes/")
    quizesObj.id=push(regRefrence).key;
    set(ref(database,`Quizes/${quizesObj.id}`),quizesObj)
    .then((res)=>{alert("data sent successfully")})
    .catch((err)=>{alert(err.message)})
    
    navigate('/adminQuiz')
  }  

  // ////////////// stepper //////////////////
  const steps = [
    {
      // label: 'Select campaign settings',
      description: <AddQuizCopm1 quizesObj={quizesObj} setQuizesObj={setQuizesObj} />,
    },
    {
      
      description:<AddQuizComp2 quizesObj={quizesObj} setQuizesObj={setQuizesObj} />,
    },
    {
      
      description:<AddQuizComp3 quizesObj={quizesObj} setQuizesObj={setQuizesObj} addQuizFormSubmit={addQuizFormSubmit} />,
    },
  ];

  const theme = useTheme();
  const [activeStep, setActiveStep] = React.useState(0);
  const maxSteps = steps.length;

  const handleNext = () => {
    // if(quizesObj.id !== "" && quizesObj.noOfQuestion !== "" && quizesObj.totalMarks !== "")
    // {
      setActiveStep((prevActiveStep) => prevActiveStep + 1);
    // }
    // else{alert("compulsory fields... Quiz Id - Tot Marks - No Of Que")}
     
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  
  return (
    <div>
      <SideBar />
<form onSubmit={addQuizFormSubmit}>

      <Container>
       

        <Box sx={{ maxWidth: 1200, flexGrow: 1 }}>
     
      <Box sx={{ height: 400, maxWidth: 1200, width: '100%', p: 2 }}>
        {steps[activeStep].description}
      </Box>
      <MobileStepper
        variant="dots"
        steps={maxSteps}
        position="static"
        activeStep={activeStep}
        nextButton={
          <Button
            size="small"
            onClick={handleNext}
            disabled={activeStep === maxSteps - 1}
          >
            Next
            {theme.direction === 'rtl' ? (
              <KeyboardArrowLeft />
            ) : (
              <KeyboardArrowRight />
            )}
          </Button>
        }
        backButton={
          <Button size="small" onClick={handleBack} disabled={activeStep === 0}>
            {theme.direction === 'rtl' ? (
              <KeyboardArrowRight />
            ) : (
              <KeyboardArrowLeft />
            )}
            Back
          </Button>
        }
      />
    </Box>
      </Container>
      </form>
    </div>
 );
};
export default AddQuiz