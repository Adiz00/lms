import React from 'react'
import StdSideBar from "../components/StdSideBar"

const StdResult = () => {
  return (
    <div><StdSideBar />
    StdResult</div>
  )
}

export default StdResult