import { Grid } from '@mui/material'
import { Container } from '@mui/system'
import React from 'react'
import StdSideBar from "../components/StdSideBar"
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import profile from "../img/profile.jpg"

// import SideBar from "../components/SideBar"
// import BtnMui from "../components/BtnMui"

const StdDashboard = () => {
  return (

    <div>
         
        <StdSideBar />
        <Container>
        <Grid
          container
          rowSpacing={3}
          columnSpacing={2}
          sx={{ width: "100%", marginLeft: "0%" }}
        >
          <Grid item xs={6} sm={6} md={8} sx={{ textAlign: "start" }}>
          
          <h2 style={{ padding: "0px", margin: "0px" }}>User Name</h2> 
          </Grid>
          <Grid item xs={6} sm={6} md={4} sx={{ textAlign: "start" }}>
          {/* <AccountCircleIcon sx={{fontsize:"100px"}}/> */}
          <img style={{height:"200px"}} src={profile} alt="" />
          </Grid>
          </Grid>
          </Container>
          </div>
  )
}

export default StdDashboard