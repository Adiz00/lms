import React from 'react'
import StdSideBar from "../components/StdSideBar"

const StdQuizes = () => {
  return (
    <div><StdSideBar />
    StdQuizes</div>
  )
}

export default StdQuizes
