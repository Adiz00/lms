import React from 'react'
import StdSideBar from "../components/StdSideBar"

const StdAnnouncement = () => {
  return (
    <div>
      <StdSideBar />StdAnnouncement</div>
  )
}

export default StdAnnouncement