import React, { useState } from "react";
import AddIcon from "@mui/icons-material/Add";
import Tooltip from "@mui/material/Tooltip";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { Alert, AlertTitle, Grid } from "@mui/material";
import InputFieldMui from "../components/InputFieldMui";
import { Container } from "@mui/system";

const AddQuizComp2 = ({ quizesObj, setQuizesObj }) => {
  // ///////  que Arr //////////////////////
  const [questionsArr, setQuestionsArr] = useState([]);
  // ///////  temp obj //////////////////////
  let [questionObj, setQuestionObj] = useState({
    question: "",
    correctAns: "",
  });
  const [optionsArr, setOptionsArr] = useState([]);
  console.log(questionObj);
  console.log(questionsArr);

  // ///////////    model     ////////////
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
    // questionObj.correctAns = "";
    // questionObj.question = "";
    // questionObj.options = [];
  };

  const handleClose = () => {
    setOpen(false);
  };

  // temp change

  const inputChangeHandler = (event) => {
    setQuestionObj((oldObj) => ({
      ...oldObj,
      [event.target.name]: event.target.value,
    }));
  };
  //         addQueHandler               ////////////////
  const addQueHandler = () => {
    // if( optionsArr[0] !== "" &&
    // optionsArr[1] !== "" &&
    // optionsArr[2] !== "" &&
    // optionsArr[3] !== "" &&
    // questionObj.correctAns !==""&&
    // questionObj.question !==""){
    questionObj.options = [...optionsArr];

    console.log(questionObj);
    // questionsArr.push(questionObj);
    setQuestionsArr([...questionsArr, questionObj]);
    // console.log(questionsArr);
    // console.log(questionObj);
    setQuizesObj((oldObj)=>({...oldObj,question:[...questionsArr],noOfQuestion:questionsArr.length}))
    
    handleClose();
    // }
    // else{
    //   alert("Fill all fields")

    // }
  };
  return (
    <div>
      {/*  /////////  render questions arr ////////////////////////*/}

      <Container>
        <Grid
          container
          rowSpacing={3}
          columnSpacing={2}
          sx={{ width: "100%", marginLeft: "0%" }}
        >
          <Grid item xs={12} sm={12} md={12} sx={{ textAlign: "start" }}>
            {questionsArr.map((x, i) => (
              <Alert severity="info" sx={{marginTop:"10px"}} key={i}>
              <AlertTitle>Question {i+1}</AlertTitle>
              {x.question}<strong>Edit !</strong>
            </Alert>
            ))}
          </Grid>
        </Grid>
      </Container>
      {/*  /////////  tooltio  && Add btn ////////////////////////*/}

      <Tooltip title="Add Question">
        <div>
          <AddIcon
            style={{ fontSize: "50px", color: "blue" }}
            onClick={handleClickOpen}
          />
        </div>
      </Tooltip>
      {/*  /////////  Dialog  ////////////////////////*/}

      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Add Question</DialogTitle>

        <DialogContent>
          <Grid container rowSpacing={3} columnSpacing={2}>
            <Grid item xs={12} sm={12} md={12}>
              <InputFieldMui
                label="Question"
                variant="filled"
                size="small"
                name="question"
                onChange={(e) => {
                  inputChangeHandler(e);
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={6}>
              <InputFieldMui
                label="Option 1"
                variant="filled"
                size="small"
                name="qption1"
                onChange={(e) => {
                  optionsArr[0] = e.target.value;
                  console.log(optionsArr);
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={6}>
              <InputFieldMui
                label="Option 2"
                variant="filled"
                size="small"
                name="Option 2"
                onChange={(e) => {
                  optionsArr[1] = e.target.value;
                  console.log(optionsArr);
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={6}>
              <InputFieldMui
                label="Option 3"
                variant="filled"
                size="small"
                name="option3"
                onChange={(e) => {
                  optionsArr[2] = e.target.value;
                  console.log(optionsArr);
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={6}>
              <InputFieldMui
                label="Option 4"
                variant="filled"
                size="small"
                name="option4"
                onChange={(e) => {
                  optionsArr[3] = e.target.value;
                  console.log(optionsArr);
                }}
              />
            </Grid>
            <Grid item xs={12} sm={12} md={12}>
              <InputFieldMui
                label="Correct Ans"
                variant="filled"
                size="small"
                name="correctAns"
                onChange={(e) => {
                  inputChangeHandler(e);
                }}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={addQueHandler}>Add</Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default AddQuizComp2;
