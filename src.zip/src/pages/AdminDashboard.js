import React from 'react'
import SideBar from '../components/SideBar'



const AdminDashboard = () => {
  return (
    <div>
      <SideBar/>
     
    </div>
  )
}

export default AdminDashboard