
import SideBar from '../components/SideBar'
import React, { useContext, useState } from "react";
import BtnMui from "../components/BtnMui";
import { useNavigate } from "react-router";
import Container from "@mui/material/Container";
import Grid from "@mui/material/Grid";
import { coursesArr } from "../Data/Data";
import { DataGrid } from "@mui/x-data-grid";
import { IsLoginContext } from "../context/UserContext";
import DeleteIcon from "@mui/icons-material/Delete";
// import {DataS} from "../Data/Data"

const AdminTrainers = () => {

   // const [couesesArr, setCouesesArr] = useState([]);

   const navigate = useNavigate();
   const goToAddCourse = () => {
     navigate("/addTrainers");
   };
   const columns = [
     // { field: 'id', headerName: 'ID', width: 70 },
     { field: "id", headerName: "course ID", width: 130 },
     { field: "courseName", headerName: "course Name", width: 130 },
     { field: "courseFee", headerName: "course Fee", width: 130 },
     { field: "courseDuration", headerName: "course Duration", width: 130 },
     { field: "isFormOpen", headerName: "is Form Open", width: 130 },
     { field: "noOfQuiz", headerName: "no Of Quiz", width: 130 },
     { field: "leadTrainerId", headerName: "lead Trainer Id", width: 130 },
     { field: "assistantTrainers", headerName: "Assistant Trainers", width: 200 },
   ];
   const actionColumn = [
     {
       field: "action",
       headerName: "Action",
       width: 130,
       
       renderCell: (params) => {
         return (
           <div style={{display: 'flex',
           alignItems: 'end',
           justifyContent: 'center',
   
         }}>
             <DeleteIcon onClick={()=>{ coursesArrContext.setCoursesArr(coursesArrContext.coursesArr.filter(item => item.id !== params.row.id ))}} />
           </div>
         );
       },
     },
   ];
   
   const coursesArrContext = useContext(IsLoginContext);
   
 
   // const [data, setData] = useState(coursesArrContext.coursesArr);
   // handleDelete=(id)=>{ setData(data.filter(item => item.id !== id ))}
 
  return (
    <div>
      <SideBar/>
      <Container>
        <Grid
          container
          rowSpacing={3}
          columnSpacing={2}
          sx={{ width: "100%", marginLeft: "0%" }}
        >
          <Grid item xs={6} sm={6} md={6} sx={{ textAlign: "start" }}>
            <h2 style={{ padding: "0px", margin: "0px" }}>Trainers</h2>
          </Grid>
          <Grid item xs={6} sm={6} md={6} sx={{ textAlign: "end" }}>
            <BtnMui
              variant="contained"
              onClick={goToAddCourse}
              text="Add Trainer"
            />
          </Grid>
          {/* <Grid item xs={12} sm={12} md={12}>
           {coursesArr.map((x,i)=>{
            return <div key={i}><span>{x.courseDuration}</span>
            <span key={i}>{x.courseDuration}</span></div> 
           })}
          </Grid> */}
          <Grid item xs={12} sm={12} md={12}>
            <div style={{ height: 400, width: "100%" }}>
              <DataGrid
                rows={coursesArrContext.coursesArr}
                columns={columns.concat(actionColumn)}
                pageSize={5}
                rowsPerPageOptions={[5]}
                checkboxSelection
              />
            </div>
          </Grid>
        </Grid>
      </Container>
    </div>
  )
}

export default AdminTrainers