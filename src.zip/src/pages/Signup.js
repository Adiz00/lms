import React from "react";

import BtnMui from "../components/BtnMui";
import InputFieldMui from "../components/InputFieldMui";
import { useNavigate } from "react-router-dom";

const Signup = () => {
  const navigate = useNavigate();

  const goToSignIn = () => {
    navigate("/login");
  };

  const signupSubmit = (e) => {
    e.preventDefault();
    navigate("/login");

  };
  return (
    <div style={{ padding: 30 }}>
      <h2>Sign Up</h2>
      <form onSubmit={signupSubmit}>
        <InputFieldMui
          sx={{ margin: "10px" }}
          id="email"
          label="email"
          variant="filled"
          onChange={(e) => console.log(e.target.value)}
          type="email"
        />
        <InputFieldMui
          sx={{ margin: "10px" }}
          id="password"
          label="password"
          variant="filled"
          onChange={(e) => console.log(e.target.value)}
          type="password"
        />
        <BtnMui
          variant="contained"
          text="Sign Up"
          sx={{ margin: "10px" }}
          type="submit"
        />
        <p>
          Alredy have an account...!{" "}
          <span
            style={{ color: "blue", cursor: "pointer" }}
            onClick={goToSignIn}
          >
            Sign In
          </span>
        </p>
      </form>
    </div>
  );
};

export default Signup;
