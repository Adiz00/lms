
import React, { useContext, useState } from "react";
import SideBar from "../components/SideBar";
import Grid from "@mui/material/Grid";
import { Box, Chip, FormControlLabel, Switch } from "@mui/material";
import Container from "@mui/material/Container";
import InputFieldMui from "../components/InputFieldMui";
import BtnMui from "../components/BtnMui";
import { useNavigate } from "react-router";
import { coursesArr } from "../Data/Data";
import { IsLoginContext } from "../context/UserContext";


const AddTeachers = () => {

    // getting courses Arr from context  
    const coursesArrContext = useContext(IsLoginContext);

    // courses obj
  const [coursesObj, setCoursesObj] = useState({
    id:"",
    isFormOpen:true,
    assistantTrainers:[],
  });

  console.log(coursesObj);

  const [assisTrainerArr, setAssisTrainerArr] = useState([
    "mohsin",
    "shunaid",
    
  ]);
  const [assisTrainer, setAssisTrainer] = useState("");
  const setArrOffAssTran = () => {
    setAssisTrainerArr((oldArr) => [...oldArr, assisTrainer]);
    // console.log(assisTrainerArr);

    setAssisTrainer("");
  };

  // inputchangeHandler
  const inputChangeHandler = (event) => {
    setCoursesObj((oldObj) => ({
      ...oldObj,
      [event.target.name]: event.target.value,
    }));
  };

  // isFormOpen Switch
  const [checked, setChecked] = useState(true);

  const handleChange = (event) => {
    setChecked(event.target.checked);

    console.log("checked", checked);
    setCoursesObj((oldObj) => ({
      ...oldObj,
      isFormOpen: checked ? false : true,
    }));
    // console.log(coursesObj.isFormOpen);

    
  };

// navigate to admin courses   
  const navigate =useNavigate();
  const goToAdminCourses =()=>{
    navigate('adminTeachers');
  }

//   Form submil
 const addCourseFormSubmit =(e)=>{
    e.preventDefault();
    // console.log("submit");
    setCoursesObj((oldObj)=> ({...oldObj,assistantTrainers:[...assisTrainerArr]}))
    console.log(coursesObj);

    if(coursesObj.id =="")
    {
        alert('enter course id')
    }

    else{

        
        coursesArrContext.setCoursesArr(oldArr => [...oldArr,coursesObj]);
        // console.log(coursesArrContext.coursesArr);
        goToAdminCourses();
    
    }
       
    
    
 }

  return (
<div>
      <SideBar />
<form onSubmit={addCourseFormSubmit}>
      <Container>
        <Grid
          container
          rowSpacing={3}
          columnSpacing={2}
          sx={{ width: "100%", marginLeft: "0%" }}
        >
          <Grid item xs={12} sm={12} md={12} sx={{ textAlign: "start" }}>
            <h2 style={{ padding: "0px", margin: "0px" }}>Teacher Info</h2>
          </Grid>
          <Grid item xs={12} sm={12} md={12} sx={{ textAlign: "start" }}>
            <FormControlLabel
              control={
                <Switch
                  checked={checked}
                  onChange={handleChange}
                  inputProps={{ "aria-label": "controlled" }}
                />
              }
              label="Is Course Open"
              labelPlacement="start"
              sx={{ padding: "0px", margin: "0px" }}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              label="Course Name"
              variant="filled"
              size="small"
              name="courseName"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
            
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              label="Course ID"
              variant="filled"
              size="small"
              name="id"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
            
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              type="number"
              label="Course Duration (months)"
              variant="filled"
              size="small"
              name="courseDuration"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              type="number"
              label="No Of Quiz"
              variant="filled"
              size="small"
              name="noOfQuiz"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              type="number"
              label="Course Fee"
              variant="filled"
              size="small"
              name="courseFee"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              label="Lead Trainer Id"
              variant="filled"
              size="small"
              name="leadTrainerId"
              onChange={(e)=>{inputChangeHandler(e);}}
            />
          </Grid>
          <Grid item xs={12} sm={12} md={12} sx={{ textAlign: "start" }}>
            <h3>Add Assitant Trainers</h3>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <InputFieldMui
              label="Assitant Trainers"
              variant="filled"
              size="small"
              //   value={assisTrainer}
              onChange={(e) => {
                setAssisTrainer(e.target.value);
              }}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4} sx={{ textAlign: "start" }}>
            <BtnMui
              variant="contained"
              text="Add"
              sx={{ marginTop: "4px" }}
              onClick={setArrOffAssTran}
            />
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={10}
            sx={{ textAlign: "start", display: "inline-block" }}
          >
            {assisTrainerArr.map((x, i) => {
              return (
                <Chip
                  sx={{ marginRight: "10px", padding: "5px" }}
                  key={i}
                  label={x}
                  variant="outlined"
                  color="success"
                />
              );
            })}
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={1}
            sx={{ textAlign: "end", display: "inline-block" }}
          >
            <BtnMui variant="outlined" text="cancel" sx={{}} onClick={()=>{navigate("adminTeachers")}} />
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={1}
            sx={{ textAlign: "end", display: "inline-block" }}
          >
            <BtnMui type="submit" variant="contained" text="submit" sx={{}} />
          </Grid>
        </Grid>
      </Container>
      </form>
    </div>
  );
  
}

export default AddTeachers