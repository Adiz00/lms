import React, { useState } from "react";

import BtnMui from "../components/BtnMui";
import InputFieldMui from "../components/InputFieldMui";
import { useNavigate } from "react-router-dom";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebase";

import Stack from '@mui/material/Stack';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import { useContext } from "react";
import {IsLoginContext} from "../context/UserContext"

const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(false  );

  // Global user context
  const currentUser = useContext(IsLoginContext);

  // navigate to sigup
  const navigate = useNavigate();
  const goToSignup = () => {
    navigate("/signup");
    
  };

  //  Login error snack
  const [open, setOpen] = React.useState(false);

  const handleClick = () => {
    setOpen(true);
  };

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };

  const loginSubmit = (e) => {

    e.preventDefault();

    signInWithEmailAndPassword(auth,email,password)
    .then((userCredentials)=>{
      const user=userCredentials.user;
      currentUser.setIsLogin(true);
      setError(false);
      handleClick();
      navigate("/");

    })
    .catch((err)=>{
      const errCode=err.code;  
      const errMessage=err.message;  
      setError(true);
      handleClick();
    })

  };

  return (
    <div style={{ padding: 30 }}>
      <h2>Login</h2>
      <form onSubmit={loginSubmit}>
        <InputFieldMui
          sx={{ margin: "10px" }}
          id="email"
          label="email"
          variant="filled"
          onChange={(e) => setEmail(e.target.value)}
          type="email"
        />
        <InputFieldMui
          sx={{ margin: "10px" }}
          id="password"
          label="password"
          variant="filled"
          onChange={(e) => setPassword(e.target.value)}
          type="password"
        />
        <BtnMui
          type="submit"
          variant="contained"
          text="Login"
          sx={{ margin: "10px" }}
        />
        <p>
          Don't have account yet...!{" "}
          <span
            style={{ color: "blue", cursor: "pointer" }}
            onClick={goToSignup}
          >
            Sign up
          </span>
        </p>
        {error && <span style={{ color: "red" }}>wrong email or password</span>}

        <Snackbar open={open} autoHideDuration={2000} onClose={handleClose}>
       {error ? <Alert onClose={handleClose} severity="error" sx={{ width: '100%' }}>
       Wrong email or password</Alert> : <Alert onClose={handleClose} severity="success" sx={{ width: '100%' }}>
       Login successfull...</Alert>
       }
      </Snackbar>

      </form>
    </div>
  );
};

export default Login;
