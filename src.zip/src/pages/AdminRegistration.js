import React, { useContext, useEffect, useState } from "react";
import BtnMui from "../components/BtnMui";
import SideBar from "../components/SideBar";
import { useNavigate } from "react-router";
import Container from "@mui/material/Container";
import Grid from "@mui/material/Grid";
import { coursesArr } from "../Data/Data";
import { DataGrid } from "@mui/x-data-grid";
import { IsLoginContext } from "../context/UserContext";
import DeleteIcon from "@mui/icons-material/Delete";
// import {DataS} from "../Data/Data"
import {getData,getDataFull} from "../firebase"

const AdminRegistration = () => {
  const[regData,setRegData]=useState([])
  useEffect(()=>{
    getData('Registration').then((data)=>{
      setRegData(data)
      // console.log(regData);
    })
  },[])
  const navigate = useNavigate();
  const goToAddCourse = () => {
    navigate("/addRegistration");
  };
  const columns = [
    // { field: 'id', headerName: 'ID', width: 70 },
    { field: "id", headerName: "Std ID", width: 130 },
    { field: "firstName", headerName: "First Name", width: 200 },
    { field: "lastName", headerName: "Last Name", width: 200 },
    { field: "course", headerName: "Course", width: 200 },
    { field: "sec", headerName: "Sec", width: 70 },
    { field: "contact", headerName: "Contact", width: 200 },
    { field: "cnic", headerName: "CNIC", width: 200 },
    { field: "fatherName", headerName: "Father Name", width: 200 },
    { field: "fatherCnic", headerName: "Father CNIC", width: 200 },
    { field: "fatherContact", headerName: "Father Contact", width: 200 },
    { field: "emergencyContact", headerName: "Emergency Contact", width: 200 },
    { field: "dob", headerName: "DOB", width: 200 },
    { field: "age", headerName: "Age", width: 200 },
    { field: "registrationDate", headerName: "Registration Date", width: 200 },
    { field: "isFeeSubmitted", headerName: "Is Fee Submitted", width: 130 },
    { field: "isApproved", headerName: "Is Approved", width: 130 },
    { field: "isActive", headerName: "Is Active", width: 130 },
  ];
  const actionColumn = [
    {
      field: "action",
      headerName: "Action",
      width: 130,
      
      renderCell: (params) => {
        return (
          <div style={{display: 'flex',
          alignItems: 'end',
          justifyContent: 'center',
  
        }}>
            <DeleteIcon onClick={()=>{ regArrContext.setRegArr(regArrContext.regArr.filter(item => item.id !== params.row.id ))}} />
          </div>
        );
      },
    },
  ];
  
  const regArrContext = useContext(IsLoginContext);
  
  return (
    <div>
      <SideBar/>
      <Container>
        <Grid
          container
          rowSpacing={3}
          columnSpacing={2}
          sx={{ width: "100%", marginLeft: "0%" }}
        >
          <Grid item xs={6} sm={6} md={6} sx={{ textAlign: "start" }}>
            <h2 style={{ padding: "0px", margin: "0px" }}>Registrations</h2>
          </Grid>
          <Grid item xs={6} sm={6} md={6} sx={{ textAlign: "end" }}>
            <BtnMui
              variant="contained"
              onClick={goToAddCourse}
              text="Add Registration"
            />
          </Grid>
          {/* <Grid item xs={12} sm={12} md={12}>
           {coursesArr.map((x,i)=>{
            return <div key={i}><span>{x.courseDuration}</span>
            <span key={i}>{x.courseDuration}</span></div> 
           })}
          </Grid> */}
          <Grid item xs={12} sm={12} md={12}>
            <div style={{ height: 400, width: "100%" }}>
              <DataGrid
                rows={regData}
                columns={columns.concat(actionColumn)}
                pageSize={5}
                rowsPerPageOptions={[5]}
                checkboxSelection
              />
            </div>
          </Grid>
        </Grid>
      </Container>
    </div>
  )
}

export default AdminRegistration