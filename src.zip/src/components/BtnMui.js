import React from "react";
import Button from "@mui/material/Button";

const BtnMui = (props) => {
  return (
    <div>
      <Button variant={props.variant} sx={props.sx} onClick={props.onClick} type={props.type}>
        {props.text} 
      </Button>
    </div>
  );
};

export default BtnMui;
