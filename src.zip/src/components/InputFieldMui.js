import React from "react";
import TextField from "@mui/material/TextField";

const InputFieldMui = (props) => {
  return (
    <div>
      <TextField
      fullWidth
      name={props.name}
        type={props.type}
        id={props.id}
        label={props.label}
        variant={props.variant}
        onChange={props.onChange}
        sx={props.sx}
        size={props.size}
        value={props.value}
      />
    </div>
  );
};

export default InputFieldMui;
