import "./App.css";

import Login from "./pages/Login";
import Signup from "./pages/Signup";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import AdminDashboard from "./pages/AdminDashboard";
import AdminCourses from "./pages/AdminCourses";
import AdminQuiz from "./pages/AdminQuiz";
import AdminTeachers from "./pages/AdminTeachers";
import AdminTrainers from "./pages/AdminTrainers";
import AdminRegistration from "./pages/AdminRegistration";
import { useContext } from "react";
import {IsLoginContext} from "../src/context/UserContext";
import AddCourse from "./pages/AddCourse";
import AddTrainers from "./pages/AddTrainers";
import AddTeachers from "./pages/AddTeachers";
import AddQuiz from "./pages/AddQuiz";
import AddRegistration from "./pages/AddRegistration";
import StudentRegistration from "./pages/StudentRegistration";
import StdDashboard from "./pages/StdDashboard";
import StdCourses from "./pages/StdCourses";
import StdQuizes from "./pages/StdQuizes";
import StdResult from "./pages/StdResult";
import StdAnnouncement from "./pages/StdAnnouncement";

function App() {
  const currentUser = useContext(IsLoginContext);
console.log(currentUser.isLogin);
  

  const RequireAuth = ({ children }) => {
    return currentUser.isLogin ? children : <Navigate to="/login" />;
  };


  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          {/* <Route
            path="/"
            element={
              <RequireAuth>
                <AdminDashboard />
              </RequireAuth>
            }
          /> */}
          <Route
            path="/"
            element={
              <RequireAuth>
                <AdminCourses />
              </RequireAuth>
            }
          />
          <Route
            path="/addCourse"
            element={
              <RequireAuth>
                <AddCourse />
              </RequireAuth>
            }
          />
          <Route
            path="/adminQuiz"
            element={
              <RequireAuth>
                <AdminQuiz />
              </RequireAuth>
            }
          />
          <Route
            path="/addQuiz"
            element={
              <RequireAuth>
                <AddQuiz />
              </RequireAuth>
            }
          />
          <Route
            path="/adminTeachers"
            element={
              <RequireAuth>
                <AdminTeachers />
              </RequireAuth>
            }
          />
          <Route
            path="/addTeachers"
            element={
              <RequireAuth>
                <AddTeachers />
              </RequireAuth>
            }
          />
          <Route
            path="/adminTrainers"
            element={
              <RequireAuth>
                <AdminTrainers />
              </RequireAuth>
            }
          />
          <Route
            path="/addTrainers"
            element={
              <RequireAuth>
                <AddTrainers />
              </RequireAuth>
            }
          />
          <Route
            path="/adminRegistration"
            element={
              <RequireAuth>
                <AdminRegistration />
              </RequireAuth>
            }
          />
          <Route
            path="/addRegistration"
            element={
              <RequireAuth>
                <AddRegistration />
              </RequireAuth>
            }
          />
          <Route
            path="/studentRegistration"
            element={
              
                <StudentRegistration />
              
            }
          />
          <Route
            path="/stdDashboard"
            element={
              
                <StdDashboard/>
            }
          />
          <Route
            path="/stdCourses"
            element={<StdCourses />}/>
          <Route
            path="/stdQuizes"
            element={<StdQuizes />}/>
          <Route
            path="/stdResult"
            element={<StdResult />}/>
          <Route
            path="/stdAnnouncements"
            element={<StdAnnouncement />}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
